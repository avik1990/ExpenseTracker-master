package com.app.expensetracker;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.expensetracker.database.DatabaseHelper;
import com.app.expensetracker.model.ExcelDataModel;
import com.app.expensetracker.utility.BaseActivity;
import com.app.expensetracker.utility.CheckForSDCard;
import com.app.expensetracker.utility.Utils;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.highlight.Highlight;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveContents;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.api.services.drive.Drive;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.TreeMap;

public class ActivitySettings extends BaseActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = "ExpenseDetails";
    Context context;
    TextView sp_month;
    ImageView btn_back, btn_menu;

    String st_year = "";
    String current_year = "";
    //for calender
    // Button mSignOut,mRevokeAccess;
    SignInButton mSignIn;
    GoogleSignInClient mGoogleSignInClient;
    GoogleSignInAccount account;
    List<ExcelDataModel> export_excel = new ArrayList<>();
    DatabaseHelper db;
    String token;
    public static final int RC_SIGN_IN = 1;
    ProgressDialog p;
    SimpleDateFormat dateFormat;
    Calendar cal;
    public final String downloadDirectory = "TransExpense";
    File apkStorage = null;
    File outputFile = null;
    String startDate = "", endDate = "";

    @Override
    protected void InitListner() {
        context = this;
        sp_month = findViewById(R.id.sp_month);
        st_year = Utils.getCurrentYear();

        dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH:mm:ss");
        cal = Calendar.getInstance();

        if (new CheckForSDCard().isSDCardPresent()) {
            apkStorage = new File(Environment.getExternalStorageDirectory() + "/" + downloadDirectory);
        } else {
            Toast.makeText(context, "Oops!! There is no SD Card.", Toast.LENGTH_SHORT).show();
        }

        if (!apkStorage.exists()) {
            apkStorage.mkdir();
        }


        mSignIn = findViewById(R.id.sign_in_btn);
        mSignIn.setSize(SignInButton.SIZE_STANDARD);

        db = new DatabaseHelper(context);

        p = new ProgressDialog(context);
        p.setMessage("Please wait...");
        p.setIndeterminate(false);
        p.setCancelable(false);

        mSignIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                signIn();

            }
        });


       /* mSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                signOut();

            }});*/

        buildGoogleSignInClient();

        // If already signed in with the app it can be obtained here

        if (account == null) {
            Toast.makeText(getApplicationContext(),
                    "You Need To Sign In First", Toast.LENGTH_SHORT).show();
        }
        if (account != null) {
            Intent intent = new Intent(this, DriveActivity.class);
            intent.putExtra("ACCOUNT", account);
            startActivity(intent);
        }
    }

    private void buildGoogleSignInClient() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        /*In order to access files in drive the scope of the permission has to be specified.
        More info on scope is available in Google Drive Api Documentation*/

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        account = GoogleSignIn.getLastSignedInAccount(this);
    }


    @Override
    protected void InitResources() {
        sp_month = findViewById(R.id.sp_month);
        sp_month.setText("Settings");
        btn_back = findViewById(R.id.btn_back);
        btn_menu = findViewById(R.id.btn_menu);
        btn_menu.setVisibility(View.GONE);
        btn_back.setVisibility(View.VISIBLE);
        btn_back.setOnClickListener(this);
        //sp_month.setText(Utils.getCurrentMonths() + " " + Utils.getCurrentYear());
    }

    @Override
    protected void InitPermission() {

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_settings;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v == btn_back) {
            finish();
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
            Intent intent = new Intent(this, DriveActivity.class);
            intent.putExtra("ACCOUNT", account);
            startActivity(intent);

        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            account = completedTask.getResult(ApiException.class);
            // Signed in successfully, show authenticated UI.
            Log.e("Check", account.getEmail() + account.getGivenName() + account.getFamilyName());
            Toast.makeText(getApplicationContext(),
                    account.getEmail() + " " + account.getGivenName(), Toast.LENGTH_LONG).show();
            // If successful you can obtain the account info using the getter methods
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.e("Sign-In", "signInResult:failed code=" + e.getStatusCode() + e);
            Toast.makeText(getApplicationContext(),
                    "Sign In Failed.Try again Later", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    public void signOut() {
        mGoogleSignInClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Toast.makeText(getApplicationContext(),
                                "Signed Out", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private class AsyncTaskExportData extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                export_excel.clear();
                export_excel = db.GetAllFinalTransactionData(startDate, endDate);
            } catch (Exception e) {

            }
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p.show();

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            ExportToExcelSheet(export_excel, startDate, endDate);
            startDate = "";
            endDate = "";
            p.dismiss();

        }
    }

    public void ExportToExcelSheet(List<ExcelDataModel> a, String startDate, String endDate) {
        HSSFWorkbook workbook = new HSSFWorkbook();
        HSSFSheet sheet = workbook.createSheet("sheet1");
        Map<String, Object[]> data = new TreeMap<>();
        data.put("1", new Object[]{"Date", "Income/Expenses", "Category", "Memo", "Amount"});
        //data.put(String.valueOf(2), new Object[]{1, "Pankaj", "Kumar"});
        if (a.size() > 0) {
            for (int i = 0; i < a.size(); i++) {
                data.put(String.valueOf(i + 2), new Object[]{a.get(i).getDate(), a.get(i).getIncome_Expenses(), a.get(i).getCategory(), a.get(i).getMemo(), a.get(i).getAmount()});
            }

            Set<String> keyset = data.keySet();
            int rownum = 0;
            for (String key : keyset) {
                // this creates a new row in the sheet
                Row row = sheet.createRow(rownum++);
                Object[] objArr = data.get(key);
                int cellnum = 0;
                for (Object obj : objArr) {
                    // this line creates a cell in the next column of that row
                    Cell cell = row.createCell(cellnum++);
                    if (obj instanceof String)
                        cell.setCellValue((String) obj);
                    else if (obj instanceof Integer)
                        cell.setCellValue((Integer) obj);
                }
            }

            outputFile = new File(apkStorage, dateFormat.format(cal.getTime()) + ".xls");//Create Output file in Main File

            try {
                FileOutputStream out = new FileOutputStream(outputFile);
                workbook.write(out);
                out.close();
                //Create New File if not present
                /*FileOutputStream fos = new FileOutputStream(outputFile);
                  fos.close();*/
                //p.dismiss();
                final Timer t = new Timer();
                t.schedule(new TimerTask() {
                    public void run() {
                        //pDialog.dismiss();
                        try {
                            Utils.shareAll(context, outputFile);
                            // openFile(context, outputFile);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        t.cancel(); // also just top the timer thread, otherwise, you may receive a crash report
                    }
                }, 6000);

            } catch (Exception e) {

            }
        } else {
            Utils.ShowToast(context, "No data for Export");
        }
    }


//    final private ResultCallback<DriveApi.DriveContentsResult> driveContentsCallback = new
//            ResultCallback<DriveApi.DriveContentsResult>() {
//                @Override
//                public void onResult(DriveApi.DriveContentsResult result) {
//                    if (!result.getStatus().isSuccess()) {
//                        showMessage("Error while trying to create new file contents");
//                        return;
//                    }
//                    final DriveContents driveContents = result.getDriveContents();
//
//                    // Perform I/O off the UI thread.
//                    new Thread() {
//                        @Override
//                        public void run() {
//                            // write content to DriveContents
//                            OutputStream outputStream = driveContents.getOutputStream();
//                            Writer writer = new OutputStreamWriter(outputStream);
//                            try {
//                                writer.write(json);
//                                writer.close();
//                            } catch (IOException e) {
//                                Log.e(TAG, e.getMessage());
//                            }
//
//                            MetadataChangeSet changeSet = new MetadataChangeSet.Builder()
//                                    .setTitle("New file.txt")
//                                    .setMimeType("json")
//                                    .setStarred(true).build();
//
//                            // create a file on root folder
//                            DriveApi.getRootFolder(getGoogleApiClient())
//                                    .createFile(getGoogleApiClient(), changeSet, driveContents)
//                                    .setResultCallback(fileCallback);
//                        }
//                    }.start();
//                }
//            };


}
