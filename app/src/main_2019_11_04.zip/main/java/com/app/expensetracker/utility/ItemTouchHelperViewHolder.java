package com.app.expensetracker.utility;

import android.support.v7.widget.helper.ItemTouchHelper;

public interface ItemTouchHelperViewHolder {

    void onItemSelected();

    void onItemClear();
}
