package com.app.expensetracker.category;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.app.expensetracker.Dashboard;
import com.app.expensetracker.R;
import com.app.expensetracker.adapter.SortCategoryAdapter;
import com.app.expensetracker.database.DatabaseHelper;
import com.app.expensetracker.model.ExcelDataModel;
import com.app.expensetracker.utility.BaseActivity;
import com.app.expensetracker.utility.EditItemTouchHelperCallback;
import com.app.expensetracker.utility.FileUtils;
import com.app.expensetracker.utility.OnStartDragListener;
import com.app.expensetracker.utility.Utils;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CategoryActivity extends BaseActivity implements View.OnClickListener, OnStartDragListener, SortCategoryAdapter.GetSortedList {

    private static final String TAG = "CategoryActivity";
    FloatingActionButton fab_add;
    Context context;
    RecyclerView rl_recyclerview;
    DatabaseHelper db;
    List<ExcelDataModel> list_exceldata = new ArrayList<>();
    List<ExcelDataModel> list_exceldata_swap = new ArrayList<>();
    ProgressDialog p;
    TextView tv_expenses, tv_income;
    TextView sp_month, tv_currentyear;
    ItemTouchHelper mItemTouchHelper;
    ImageView iv_dropdown, btn_menu, btn_back;

    private static final int RESULT_UPDATED = 999;
    SortCategoryAdapter mAdapter;

    @Override
    protected void InitListner() {
        context = this;

        db = new DatabaseHelper(context);
        fab_add.setOnClickListener(this);

        p = new ProgressDialog(context);
        p.setMessage("Please wait...");
        p.setIndeterminate(false);
        p.setCancelable(false);

        new FetchData().execute();

    }


    @Override
    protected void InitResources() {
        tv_currentyear = findViewById(R.id.tv_currentyear);
        rl_recyclerview = findViewById(R.id.rl_recyclerview);
        rl_recyclerview.setLayoutManager(new LinearLayoutManager(context));
        tv_expenses = findViewById(R.id.tv_expenses);
        tv_income = findViewById(R.id.tv_income);
        fab_add = findViewById(R.id.fab_add);
        iv_dropdown = findViewById(R.id.iv_dropdown);
        iv_dropdown.setVisibility(View.GONE);
        sp_month = findViewById(R.id.sp_month);
        btn_menu = findViewById(R.id.btn_menu);
        btn_menu.setVisibility(View.GONE);
        btn_back = findViewById(R.id.btn_back);
        btn_back.setVisibility(View.VISIBLE);
        btn_back.setOnClickListener(this);
        // sp_month.setVisibility(View.GONE);
        sp_month.setText("Categories");
    }

    @Override
    protected void InitPermission() {

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_category;
    }

    @Override
    public void onClick(View v) {
        if (v == fab_add) {
            Intent i = new Intent(context, AddCategory.class);
            startActivityForResult(i, RESULT_UPDATED);
        } else if (v == btn_back) {
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onStartDrag(RecyclerView.ViewHolder viewHolder) {
        mItemTouchHelper.startDrag(viewHolder);
    }

    @Override
    public void sortedList(List<ExcelDataModel> mPersonList) {
        list_exceldata_swap = mPersonList;
        for (int i = 0; i < mPersonList.size(); i++) {
            Log.d("SwapCat", mPersonList.get(i).getCategory());
        }
    }

    private class AsyncSwap extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            db.UpdateSortFieldSwap(list_exceldata_swap);
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p.show();

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            p.dismiss();
            Utils.ShowToast(context, "Sorted Successfully");
            finish();
        }
    }


    private class FetchData extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            list_exceldata = db.GetAllCAtegoryDataSortedByName();
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p.show();

        }

        @SuppressLint("ClickableViewAccessibility")
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (list_exceldata.size() > 0) {
                setUpAdapter();
                rl_recyclerview.setOnTouchListener((view, event) -> {
                    int eventaction = event.getAction();

                    switch (eventaction) {
                        case MotionEvent.ACTION_DOWN:
                            fab_add.hide();
                            //Toast.makeText(context, "ACTIO", Toast.LENGTH_SHORT).show();
                            break;

                        case MotionEvent.ACTION_MOVE:
                            //Toast.makeText(context, "ACTIOMove", Toast.LENGTH_SHORT).show();
                            fab_add.hide();
                            break;

                        case MotionEvent.ACTION_UP:
                            //Toast.makeText(context, "ACTIOUp", Toast.LENGTH_SHORT).show();
                            fab_add.show();
                            break;
                    }
                    return false;
                });
            }
            p.dismiss();
        }
    }

    private void setUpAdapter() {
        if (list_exceldata.size() > 0) {
            mAdapter = new SortCategoryAdapter(this, list_exceldata, this, this);
            ItemTouchHelper.Callback callback = new EditItemTouchHelperCallback(mAdapter);
            mItemTouchHelper = new ItemTouchHelper(callback);
            mItemTouchHelper.attachToRecyclerView(rl_recyclerview);
            rl_recyclerview.setAdapter(mAdapter);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RESULT_UPDATED:
                new AsyncTaskUpdateList().execute();
                break;
        }
    }


    private class AsyncTaskUpdateList extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            list_exceldata = db.GetAllCAtegoryDataSortedByName();
            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p.show();

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (mAdapter != null) {
                mAdapter.updateReceiptsList(list_exceldata);
            }
            p.dismiss();
        }
    }
}