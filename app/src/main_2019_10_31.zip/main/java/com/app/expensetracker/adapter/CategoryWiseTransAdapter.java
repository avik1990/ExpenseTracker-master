package com.app.expensetracker.adapter;

import android.content.Context;
import android.database.DataSetObserver;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.app.expensetracker.R;
import com.app.expensetracker.model.ExcelDataModel;
import com.app.expensetracker.utility.CircularTextView;
import com.app.expensetracker.utility.Utils;

import java.util.List;

/**
 * Created by Avik on 26/9/2019.
 */

public class CategoryWiseTransAdapter extends BaseExpandableListAdapter {

    private Context context;
    List<ExcelDataModel> list_shareofshelf;
    ChildClicked childClicked;

    public CategoryWiseTransAdapter(Context context, List<ExcelDataModel> list_shareofshelf, ChildClicked childClicked) {
        this.context = context;
        this.list_shareofshelf = list_shareofshelf;
        this.childClicked = childClicked;
    }

    public void updateReceiptsList(List<ExcelDataModel> list_shareofshelf) {
        this.list_shareofshelf = list_shareofshelf;
        this.notifyDataSetChanged();
    }

    public interface ChildClicked {
        void childClicked(int id);
    }


    @Override
    public Object getChild(int listPosition, int expandedListPosition) {
        return this.list_shareofshelf.get(listPosition);
    }

    @Override
    public long getChildId(int listPosition, int expandedListPosition) {
        return expandedListPosition;
    }

    @Override
    public View getChildView(final int listPosition, final int expandedListPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View cview = layoutInflater.inflate(R.layout.list_child_sos, null);

        RelativeLayout child_container = cview.findViewById(R.id.child_container);
        TextView tv_category = cview.findViewById(R.id.tv_category);
        TextView tv_expense = cview.findViewById(R.id.tv_expense);
        ImageView iv_icon = cview.findViewById(R.id.iv_icon);
        ImageView iv_payment = cview.findViewById(R.id.iv_payment);

        CircularTextView tv_payment_mode = cview.findViewById(R.id.tv_payment_mode);
        tv_payment_mode.setSolidColor("#FF0000");

        try {
            if (list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getIcon_name() != null &&
                    !list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getIcon_name().isEmpty()) {
                int imageid = context.getResources().getIdentifier(list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getIcon_name(), "drawable", context.getPackageName());
                iv_icon.setImageResource(imageid);
            } else {
                iv_icon.setImageResource(R.drawable.ic_gray_no_img);
            }
        } catch (Exception e) {
            iv_icon.setImageResource(R.drawable.ic_gray_no_img);
        }

        Log.d("Expenses", list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getIncome_Expenses());
        if (list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getIncome_Expenses().equalsIgnoreCase("Expenses")) {
            tv_expense.setText("-" + list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getAmount());
        } else {
            tv_expense.setText(list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getAmount());
        }


        if (list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getPayment_mode().equalsIgnoreCase("Cash")) {
            tv_payment_mode.setText("ca");
            iv_payment.setImageResource(R.drawable.ic_rupee_icon);
        } else if (list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getPayment_mode().equalsIgnoreCase("Credit Card")) {
            tv_payment_mode.setText("cc");
            iv_payment.setImageResource(R.drawable.ic_visa_icon);
        } else if (list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getPayment_mode().equalsIgnoreCase("Cheque/Debit Card")) {
            tv_payment_mode.setText("ch");
            iv_payment.setImageResource(R.drawable.ic_cheque_icon);
        }


        child_container.setOnClickListener(new View.OnClickListener() {

            @Override

            public void onClick(View v) {
                if (!list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getId().isEmpty()) {
                    childClicked.childClicked(Integer.parseInt(list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getId()));
                }
            }
        });

        if (!list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getMemo().isEmpty()) {
            tv_category.setText(list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getMemo());
        } else {
            tv_category.setText(list_shareofshelf.get(listPosition).getGroupFocAll().get(expandedListPosition).getCategory());
        }

        if (expandedListPosition == list_shareofshelf.get(listPosition).getGroupFocAll().size() - 1) {
            child_container.setBackgroundResource(R.drawable.card_bottom_round);
        }

        return cview;
    }


    @Override
    public int getChildrenCount(int listPosition) {
        return list_shareofshelf.get(listPosition).getGroupFocAll().size();
    }

    @Override
    public Object getGroup(int listPosition) {
        return list_shareofshelf.get(listPosition).getGroupFocAll();
    }

    @Override
    public int getGroupCount() {
        return list_shareofshelf.size();
    }

    @Override
    public long getGroupId(int listPosition) {
        return listPosition;
    }

    @Override
    public View getGroupView(int listPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.list_parent_sos, null);
        ExpandableListView eLV = (ExpandableListView) parent;
        eLV.expandGroup(listPosition);
        TextView listTitleTextView = view.findViewById(R.id.listTitle);

        TextView tv_expenditures = view.findViewById(R.id.tv_expenditures);
        listTitleTextView.setText(Utils.getFormattedDate(list_shareofshelf.get(listPosition).getDate()));

        tv_expenditures.setText("Expenses: " + list_shareofshelf.get(listPosition).getExp_amt_() + " Income: " + list_shareofshelf.get(listPosition).getInc_amt_());


        return view;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPosition, int expandedListPosition) {
        return true;
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        super.registerDataSetObserver(observer);
    }
}
