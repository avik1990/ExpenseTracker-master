package com.app.expensetracker.user;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import com.app.expensetracker.R;
import com.app.expensetracker.adapter.SortCategoryAdapter;
import com.app.expensetracker.adapter.UserAdapter;
import com.app.expensetracker.database.DatabaseHelper;
import com.app.expensetracker.model.ExcelDataModel;
import com.app.expensetracker.utility.BaseActivity;
import com.app.expensetracker.utility.OnStartDragListener;
import com.app.expensetracker.utility.Utils;

import java.util.ArrayList;
import java.util.List;

public class AddUserActivity extends BaseActivity implements View.OnClickListener, UserAdapter.GetUserIDAdapter {

    private static final String TAG = "AddUserActivity";
    FloatingActionButton fab_add;
    Context context;
    DatabaseHelper db;
    ProgressDialog p;
    TextView tv_expenses, tv_income;
    TextView sp_month, tv_currentyear;
    ImageView iv_dropdown, btn_menu, btn_back;
    EditText et_category;
    long returnedId;
    List<ExcelDataModel> listUser = new ArrayList<>();
    UserAdapter userAdapter;
    RecyclerView rl_recyclerview;


    @Override
    protected void InitListner() {
        context = this;
        db = new DatabaseHelper(context);
        fab_add.setOnClickListener(this);

        p = new ProgressDialog(context);
        p.setMessage("Please wait...");
        p.setIndeterminate(false);
        p.setCancelable(false);
        fetchUserData();
    }

    @Override
    protected void InitResources() {
        rl_recyclerview = findViewById(R.id.rl_recyclerview);
        et_category = findViewById(R.id.et_category);
        tv_currentyear = findViewById(R.id.tv_currentyear);
        tv_expenses = findViewById(R.id.tv_expenses);
        tv_income = findViewById(R.id.tv_income);
        fab_add = findViewById(R.id.fab_add);
        iv_dropdown = findViewById(R.id.iv_dropdown);
        iv_dropdown.setVisibility(View.GONE);
        sp_month = findViewById(R.id.sp_month);
        btn_menu = findViewById(R.id.btn_menu);
        btn_menu.setVisibility(View.GONE);
        btn_back = findViewById(R.id.btn_back);
        btn_back.setVisibility(View.VISIBLE);
        btn_back.setOnClickListener(this);
        //sp_month.setVisibility(View.GONE);
        sp_month.setText("Add Users");
    }

    @Override
    protected void InitPermission() {

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_adduser;
    }

    @Override
    public void onClick(View v) {
        if (v == fab_add) {
            if (et_category.getText().toString().trim().isEmpty()) {
                Utils.ShowToast(context, "Add User Name");
                return;
            }

            ExcelDataModel excelDataModel = new ExcelDataModel();
            excelDataModel.setUserName(et_category.getText().toString().trim());

            returnedId = db.addUser(excelDataModel);

            if (returnedId < 0) {
                Utils.ShowToast(context, "User Already Exists");
            } else {
                // finish();
                et_category.setText("");
                fetchUserData();
                Utils.ShowToast(context, "User Added");
            }

        } else if (v == btn_back) {
            finish();
        }
    }

    public void fetchUserData() {
        listUser.clear();
        listUser = db.getAllUsers();
        if (listUser.size() > 0) {
            //Context mContext, List<ExcelDataModel> countryList, GetUserIDAdapter getMonthFromAdapter
            userAdapter = new UserAdapter(context, listUser, this);
            rl_recyclerview.setAdapter(userAdapter);
        }

    }

    @Override
    public void returnPosition(int pos) {
        Utils.ShowToast(context, "" + pos);
    }
}