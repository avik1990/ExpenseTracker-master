package com.app.expensetracker;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.app.expensetracker.adapter.CategoryAdapter;
import com.app.expensetracker.database.DatabaseHelper;
import com.app.expensetracker.model.CategoryModel;
import com.app.expensetracker.model.ExcelDataModel;
import com.app.expensetracker.model.TransactionType;
import com.app.expensetracker.utility.BaseActivity;
import com.app.expensetracker.utility.Utils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class AddExpenseIncome extends BaseActivity implements View.OnClickListener, CategoryAdapter.GetMonthFromAdapter {

    private static final String TAG = "AddExpenseIncome";
    Context context;
    DatabaseHelper db;
    List<CategoryModel> listcat = new ArrayList<>();
    List<TransactionType> list_transtype = new ArrayList<>();
    List<ExcelDataModel> list_users = new ArrayList<>();
    CategoryAdapter categoryAdapter;
    RecyclerView cat_recyclerview;
    Calendar myCalendar = Calendar.getInstance();
    String cat_id = "", cat_name = "";
    String[] users;
    String[] usersID;
    LinearLayout ll_monthView;
    TextView sp_month;
    String transaction_type = "";
    ImageView btn_back, btn_menu;

    /////calculator view
    EditText et_memo;
    TextView et_sum;
    TextView tv_7;
    TextView tv_8;
    TextView tv_9;
    TextView tv_date;
    TextView tv_4;
    TextView tv_5;
    TextView tv_6;
    TextView tv_plus;
    TextView tv_1;
    TextView tv_2;
    TextView tv_3;
    TextView tv_minus;
    TextView tv_decimal;
    TextView tv_0;
    ImageView tv_clr;
    ImageView iv_equals;
    LinearLayout ll_submit;
    String current_date = "";
    ImageView iv_calc_cat;
    //////////////////////////////
    String userID = "";
    List<ExcelDataModel> list_from_transtype = new ArrayList<>();

    String trans_id = "";
    String from = "";

    @Override
    protected void InitListner() {
        context = this;
        db = new DatabaseHelper(context);
        ll_monthView.setOnClickListener(this);
        list_users = db.getAllUsers();
        //Utils.ShowToast(context, "Size" + list_users.size());
        if (from.equalsIgnoreCase("Dashboard")) {
            listcat.clear();
            list_transtype.clear();
            list_transtype = db.GetAllTransactionType();

            if (list_transtype.size() > 0) {
                sp_month.setText(list_transtype.get(0).getTrans_type());
                transaction_type = list_transtype.get(0).getTrans_type();
                loadCategories(list_transtype.get(0).getTrans_type());
            }
            tv_minus.setText("MySelf");
            userID = "1";

           /* if (from.equalsIgnoreCase("Dashboard")) {

            } else if (from.equalsIgnoreCase("ExpenseDetails")) {
            *//*Utils.setIsUpdated(context, true);
            db.UpdateTransactionDataTO_TransactionTable(excelDataModel, trans_id);*//*
            }*/


        } else if (from.equalsIgnoreCase("ExpenseDetails")) {
            trans_id = getIntent().getStringExtra("trans_id");
            list_from_transtype.clear();
            list_from_transtype = db.GetTransactionById(trans_id);
            listcat.clear();
            list_transtype.clear();
            list_transtype = db.GetAllTransactionType();
            cat_id = list_from_transtype.get(0).getCat_id();
            current_date = list_from_transtype.get(0).getDate();

            if (list_transtype.size() > 0) {
                sp_month.setText(list_from_transtype.get(0).getIncome_Expenses());
                transaction_type = list_from_transtype.get(0).getIncome_Expenses();
                loadCategories(list_from_transtype.get(0).getIncome_Expenses());
            }

            setCalculatorData();
        }

        calculator();
    }

    private void setCalculatorData() {
        et_memo.setText(list_from_transtype.get(0).getMemo());
        et_sum.setText(list_from_transtype.get(0).getAmount());
        tv_date.setText(list_from_transtype.get(0).getDate());
        tv_minus.setText(list_from_transtype.get(0).getUserName());
        userID = list_from_transtype.get(0).getUserId();

        try {
            if (list_from_transtype.get(0).getPayment_mode().isEmpty()) {
                tv_plus.setText("Cash");
            } else {
                tv_plus.setText(list_from_transtype.get(0).getPayment_mode());
            }
        } catch (Exception e) {
        }
    }

    private void loadCategories(String trans_type) {
        listcat.clear();
        listcat = db.GetAllCatgories(trans_type);
        if (listcat.size() > 0) {
            categoryAdapter = new CategoryAdapter(context, listcat, this, cat_id);
            cat_recyclerview.setAdapter(categoryAdapter);
        }
    }


    @Override
    protected void InitResources() {
        from = getIntent().getStringExtra("from");


        current_date = Utils.getCurrentDate();
        cat_recyclerview = findViewById(R.id.cat_recyclerview);
        cat_recyclerview.setLayoutManager(new GridLayoutManager(context, 4));
        iv_calc_cat = findViewById(R.id.iv_calc_cat);
        ll_monthView = findViewById(R.id.ll_monthView);
        sp_month = findViewById(R.id.sp_month);

        btn_back = findViewById(R.id.btn_back);
        btn_menu = findViewById(R.id.btn_menu);
        btn_menu.setVisibility(View.GONE);
        btn_back.setVisibility(View.VISIBLE);
        btn_back.setOnClickListener(this);
        //calculator
        et_memo = findViewById(R.id.et_memo);
        et_sum = findViewById(R.id.et_sum);
        ll_submit = findViewById(R.id.ll_submit);
        tv_7 = findViewById(R.id.tv_7);
        tv_8 = findViewById(R.id.tv_8);
        tv_9 = findViewById(R.id.tv_9);
        tv_date = findViewById(R.id.tv_date);
        tv_4 = findViewById(R.id.tv_4);
        tv_5 = findViewById(R.id.tv_5);
        tv_6 = findViewById(R.id.tv_6);
        tv_plus = findViewById(R.id.tv_plus);
        tv_1 = findViewById(R.id.tv_1);
        tv_2 = findViewById(R.id.tv_2);
        tv_3 = findViewById(R.id.tv_3);
        tv_0 = findViewById(R.id.tv_0);

        tv_minus = findViewById(R.id.tv_minus);


        tv_minus.setEnabled(true);
        tv_decimal = findViewById(R.id.tv_decimal);
        tv_clr = findViewById(R.id.tv_clr);
        iv_equals = findViewById(R.id.iv_equals);


    }

    @Override
    protected void InitPermission() {

    }

    @Override
    protected int getLayout() {
        return R.layout.activity_addexpense;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        if (v == ll_monthView) {
            if (list_transtype.size() > 0) {
                PopupMenu popup = new PopupMenu(context, ll_monthView);
                for (int i = 0; i < list_transtype.size(); i++) {
                    popup.getMenu().add(list_transtype.get(i).getTrans_type());
                }

                popup.setOnMenuItemClickListener(item -> {
                    cat_id = "";
                    transaction_type = item.getTitle().toString();
                    loadCategories(transaction_type);
                    sp_month.setText(transaction_type);
                    return true;
                });
                popup.show();//showing popup menu
            }
        } else if (v == btn_back) {
            finish();
        }
    }


    @Override
    public void returnedMonth(String cat_id, String sortOrder) {
        this.cat_id = cat_id;
    }

    @Override
    public void returnedCategoryName(String catname) {
        this.cat_name = catname;
    }

    @Override
    public void returnPosition(int pos) {
        if (listcat.get(pos).getCat_iconname() != null) {
            int imageid = getResources().getIdentifier(listcat.get(pos).getCat_iconname(), "drawable", getPackageName());
            iv_calc_cat.setImageResource(imageid);
        }
    }

    public void calculator() {
        tv_date.setText(current_date);
        et_sum = findViewById(R.id.et_sum);

        tv_7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }
                et_sum.append("7");
            }
        });
        tv_8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("8");
            }
        });
        tv_9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("9");
            }
        });
        tv_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd = new DatePickerDialog(context, fromdate,
                        myCalendar.get(Calendar.YEAR),
                        myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                //  dpd.getDatePicker().setMinDate(System.currentTimeMillis());
                dpd.show();

            }
        });
        tv_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("4");
            }
        });
        tv_5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("5");
            }
        });
        tv_6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("6");
            }
        });
        tv_plus.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
               /* if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                if (et_sum.getText().toString().equalsIgnoreCase("-")) {
                    et_sum.setText("+");
                }

                if (et_sum.getText().length() > 0) {
                    Character value = et_sum.getText().toString().charAt(et_sum.getText().toString().length() - 1);

                    if (value.toString().equalsIgnoreCase("+")) {
                        return;
                    }
                    if (value.toString().equalsIgnoreCase("-")) {
                        return;
                    }

                    try {
                        if (et_sum.getText().toString().contains("+")) {
                            String val[] = et_sum.getText().toString().split("\\+");
                            String a = val[0];
                            String b = val[1];
                            Log.d("TWOVal", a + " " + b);
                            double sum = Double.parseDouble(a) + Double.parseDouble(b);
                            et_sum.setText(new DecimalFormat("##.##").format(sum));
                        } else if (et_sum.getText().toString().contains("-")) {
                            String val[] = et_sum.getText().toString().split("\\-");
                            String a = val[0];
                            String b = val[1];
                            Log.d("TWOVal", a + " " + b);
                            double sum = Double.parseDouble(a) - Double.parseDouble(b);
                            et_sum.setText(new DecimalFormat("##.##").format(sum));
                        }
                    } catch (Exception e) {
                    }
                    et_sum.append("+");
                }*/
                String[] payment_mode = {"Cash", "Credit Card", "Cheque/Debit Card"};
                PopupMenu popup = new PopupMenu(context, tv_plus);
                for (int i = 0; i < payment_mode.length; i++) {
                    popup.getMenu().add(payment_mode[i]);
                }

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        tv_plus.setText(item.getTitle().toString());
                        return true;
                    }
                });
                popup.show();
            }
        });

        tv_minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (list_users.size() > 0) {
                    users = new String[list_users.size()];
                    usersID = new String[list_users.size()];

                    for (int i = 0; i < list_users.size(); i++) {
                        users[i] = list_users.get(i).getUserName();
                        usersID[i] = list_users.get(i).getUserId();
                    }

                    PopupMenu popup = new PopupMenu(context, tv_minus);
                    for (int i = 0; i < users.length; i++) {
                        popup.getMenu().add(users[i]);
                    }

                    popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        public boolean onMenuItemClick(MenuItem item) {
                            tv_minus.setText(item.getTitle().toString());
                            userID = list_users.get(Arrays.asList(users).indexOf(item.getTitle().toString())).getUserId();
                            Utils.ShowToast(context, userID);
                            return true;
                        }
                    });
                    popup.show();
                }

                /*if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                if (et_sum.getText().toString().equalsIgnoreCase("+")) {
                    et_sum.setText("-");
                }

                if (et_sum.getText().toString().length() > 0) {
                    Character value = et_sum.getText().toString().charAt(et_sum.getText().toString().length() - 1);
                    if (value.toString().equalsIgnoreCase("+")) {
                        return;
                    }
                    if (value.toString().equalsIgnoreCase("-")) {
                        return;
                    }

                    try {
                        if (et_sum.getText().toString().contains("-")) {
                            String val[] = et_sum.getText().toString().split("\\-");
                            String a = val[0];
                            String b = val[1];
                            Log.d("TWOVal", a + " " + b);
                            double sum = Double.parseDouble(a) - Double.parseDouble(b);
                            et_sum.setText(new DecimalFormat("##.##").format(sum));
                        } else if (et_sum.getText().toString().contains("+")) {
                            String val[] = et_sum.getText().toString().split("\\+");
                            String a = val[0];
                            String b = val[1];
                            Log.d("TWOVal", a + " " + b);
                            double sum = Double.parseDouble(a) + Double.parseDouble(b);
                            et_sum.setText(new DecimalFormat("##.##").format(sum));
                        }

                    } catch (Exception e) {

                    }

                    et_sum.append("-");

                }*/


            }
        });
        tv_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }
                et_sum.append("1");
            }
        });
        tv_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }

                et_sum.append("2");
            }
        });
        tv_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_sum.getText().toString().equalsIgnoreCase("0")) {
                    et_sum.setText("");
                }
                et_sum.append("3");
            }
        });

        tv_0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_sum.append("0");
            }
        });
        tv_decimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!et_sum.getText().toString().contains(".")) {
                    et_sum.append(".");
                }
            }
        });

        tv_clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String value = et_sum.getText().toString();
                if (!value.isEmpty()) {
                    //if (!value.equalsIgnoreCase("0")) {
                    value = value.substring(0, value.length() - 1);
                    if (!value.isEmpty()) {
                        et_sum.setText(value);
                    } else {
                        et_sum.setText("0");
                    }
                } else {
                    et_sum.setText("0");
                }
            }
        });

        ll_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cat_id.isEmpty()) {
                    Utils.ShowToast(context, "Select a category");
                    return;
                }
               /* if (et_memo.getText().toString().isEmpty()) {
                    Utils.ShowToast(context, "Enter Memo");
                    return;
                }*/
                if (et_sum.getText().toString().isEmpty()) {
                    Utils.ShowToast(context, "Enter Expense/Income Amount");
                    return;
                }

                try {
                    if (et_sum.getText().toString().contains("+")) {
                        String val[] = et_sum.getText().toString().split("\\+");
                        String a = val[0];
                        String b = val[1];
                        //Log.d("TWOVal", a + " " + b);
                        double sum = Double.parseDouble(a) + Double.parseDouble(b);
                        et_sum.setText(new DecimalFormat("##.##").format(sum));
                    } else if (et_sum.getText().toString().contains("-")) {
                        String val[] = et_sum.getText().toString().split("\\-");
                        String a = val[0];
                        String b = val[1];
                        //Log.d("TWOVal", a + " " + b);
                        double sum = Double.parseDouble(a) - Double.parseDouble(b);
                        et_sum.setText(new DecimalFormat("##.##").format(sum));
                    }
                } catch (Exception e) {
                }

                if (et_sum.getText().toString().trim().contains("+") || et_sum.getText().toString().trim().contains("-")) {
                    Utils.ShowToast(context, "Enter Amount is not correct");
                    return;
                }


                ExcelDataModel excelDataModel = new ExcelDataModel();
                excelDataModel.setDate(tv_date.getText().toString().trim());
                excelDataModel.setIncome_Expenses(transaction_type);
                excelDataModel.setCat_id(cat_id);
                excelDataModel.setPayment_mode(tv_plus.getText().toString());
                excelDataModel.setUserId(userID);

                if (!et_memo.getText().toString().trim().isEmpty()) {
                    excelDataModel.setMemo(et_memo.getText().toString().trim());
                } else {
                    excelDataModel.setMemo(cat_name);
                }

                if (!et_sum.getText().toString().trim().equalsIgnoreCase("0")) {
                    excelDataModel.setAmount(trimLeadingZeros(et_sum.getText().toString().trim()));
                } else {
                    excelDataModel.setAmount(et_sum.getText().toString().trim());
                }

                if (!current_date.isEmpty()) {
                    String d[] = current_date.split("-");
                    String mon = d[1];
                    excelDataModel.setMonth(mon);
                }

                if (from.equalsIgnoreCase("Dashboard")) {
                    Utils.setIsUpdated(context, true);
                    db.AddTransactionDataTO_TransactionTable(excelDataModel);
                } else if (from.equalsIgnoreCase("ExpenseDetails")) {
                    Utils.setIsUpdated(context, true);
                    db.UpdateTransactionDataTO_TransactionTable(excelDataModel, trans_id);
                }
                finish();
            }
        });
    }


    public static String trimLeadingZeros(String source) {
        for (int i = 0; i < source.length(); ++i) {
            char c = source.charAt(i);
            if (c != '0') {
                return source.substring(i);
            }
        }
        return ""; // or return "0";
    }


    DatePickerDialog.OnDateSetListener fromdate = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String years;
            String month1 = "";
            String dayofMonth = "";
            years = "" + year;
            int month = monthOfYear;
            month = month + 1;
            if (month < 10) {
                month1 = "0" + month;
            } else {
                month1 = String.valueOf(month);
            }
            //String startDate = dayOfMonth + "/" + month1 + "/" + years;
            if (dayOfMonth < 10) {
                dayofMonth = "0" + dayOfMonth;
            } else {
                dayofMonth = String.valueOf(dayOfMonth);
            }

            String startDate = years + "-" + month1 + "-" + dayofMonth;
            tv_date.setText(startDate);
        }
    };
}
